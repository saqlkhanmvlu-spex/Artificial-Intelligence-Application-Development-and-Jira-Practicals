import pandas as pd
import streamlit as st

from modules.data_loader import load_uploaded_file
from modules.profiler import profile_dataset, dataset_health
from modules.recommendations import recommend_analyses
from modules.statistics import descriptive_statistics
from modules.visualization import build_chart
from modules.probability import distribution_simulation, dice_simulation, binomial_simulation
from modules.inferential import confidence_interval, bootstrap_confidence_interval, hypothesis_test, ab_test, anova_test
from modules.sampling import sample_series
from modules.ml import classification_model, regression_model, decision_tree_model
from modules.search import search_demo, agent_demo
from modules.time_series import time_series_analysis, forecast_series
from modules.optimization import inventory_simulation, linear_programming_demo
from modules.decision import expected_value_analysis

st.set_page_config(
    page_title="Nova — Data Intelligence Studio",
    page_icon="✦",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# -----------------------------------------------------------------------------
# VISUAL SYSTEM — deliberately rebuilt from scratch.
# -----------------------------------------------------------------------------
st.markdown(r'''<style>
:root{
  --paper:#f7f8fa;
  --surface:#ffffff;
  --ink:#111827;
  --muted:#6b7280;
  --muted-2:#8b95a1;
  --line:#e5e7eb;
  --blue:#2563eb;
  --blue-soft:#eff6ff;
  --green:#16a34a;
  --shadow:0 14px 38px rgba(17,24,39,.06);
}
html, body, [class*="css"], button, input, textarea, select,
[data-testid="stMarkdownContainer"], [data-testid="stWidgetLabel"]{
  font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","SF Pro Text",
  "Segoe UI",Inter,Arial,sans-serif !important;
  -webkit-font-smoothing:antialiased !important;
  text-rendering:optimizeLegibility !important;
}
body{background:var(--paper) !important;color:var(--ink) !important;}
#MainMenu,footer,header[data-testid="stHeader"],[data-testid="stDecoration"],
[data-testid="stToolbar"]{display:none !important;}
.block-container{
  width:min(1320px,calc(100% - 48px)) !important;
  max-width:1320px !important;
  margin:0 auto !important;
  padding:20px 0 72px !important;
}

/* Header */
.nova-header{
  display:flex;align-items:center;justify-content:space-between;
  min-height:68px;padding:12px 16px;margin:0 0 24px;
  background:rgba(255,255,255,.88);
  border:1px solid rgba(17,24,39,.08);
  border-radius:20px;
  box-shadow:0 10px 30px rgba(17,24,39,.055);
  backdrop-filter:blur(16px);
}
.nova-brand{display:flex;align-items:center;gap:12px;min-width:0;}
.nova-mark{
  width:40px;height:40px;flex:0 0 auto;display:grid;place-items:center;
  border-radius:12px;background:#111827;color:#fff;font-size:17px;font-weight:800;
}
.nova-name{font-size:19px;line-height:1;font-weight:800;letter-spacing:-.7px;}
.nova-sub{
  margin-top:5px;font-size:8px;line-height:1;color:#9099a5;
  font-weight:800;letter-spacing:1.65px;text-transform:uppercase;white-space:nowrap;
}
.nova-status{
  display:flex;align-items:center;gap:8px;padding:8px 11px;
  border:1px solid var(--line);border-radius:999px;background:#fff;
  color:#6b7280;font-size:9px;font-weight:750;letter-spacing:1px;
  text-transform:uppercase;white-space:nowrap;
}
.nova-dot{width:7px;height:7px;border-radius:50%;background:var(--green);
box-shadow:0 0 0 4px rgba(22,163,74,.10);}

/* Navigation */
.nav-caption{
  margin:0 0 8px 2px;font-size:9px;color:#9aa1ac;font-weight:800;
  letter-spacing:1.8px;text-transform:uppercase;
}
[data-testid="stButton"] > button{
  min-height:42px !important;border-radius:12px !important;
  border:1px solid var(--line) !important;background:#fff !important;
  color:#4b5563 !important;font-size:12px !important;font-weight:650 !important;
  box-shadow:0 2px 8px rgba(17,24,39,.025) !important;transition:all .16s ease !important;
}
[data-testid="stButton"] > button:hover{
  transform:translateY(-1px);border-color:#cbd5e1 !important;
  box-shadow:0 7px 16px rgba(17,24,39,.06) !important;
}
[data-testid="stButton"] > button[kind="primary"]{
  background:#111827 !important;border-color:#111827 !important;color:#fff !important;
  box-shadow:0 7px 18px rgba(17,24,39,.13) !important;
}

/* Hero */
.hero-grid{
  display:grid;grid-template-columns:minmax(0,1.08fr) minmax(320px,.92fr);
  gap:52px;align-items:stretch;margin:40px 0 44px;
}
.hero-kicker{
  margin-bottom:18px;font-size:10px;line-height:1;color:#8b95a1;
  font-weight:800;letter-spacing:2px;text-transform:uppercase;
}
.hero-title{
  max-width:720px;margin:0 0 18px;color:#0f172a;
  font-size:clamp(48px,6vw,76px);line-height:.98;letter-spacing:-4px;font-weight:800;
}
.hero-title em{font-style:normal;color:var(--blue);}
.hero-copy{
  max-width:680px;margin:0 0 24px;font-size:15px;line-height:1.7;color:#626b77;
}
.hero-note{
  max-width:500px;padding:2px 0 2px 14px;border-left:3px solid #111827;
  color:#3f4650;font-size:12px;line-height:1.55;
}

/* Visual */
.matrix{
  position:relative;min-height:320px;overflow:hidden;padding:24px;
  border:1px solid #243147;border-radius:24px;
  background:radial-gradient(circle at 80% 20%,rgba(37,99,235,.18),transparent 34%),#0f172a;
  color:#fff;box-shadow:0 18px 45px rgba(15,23,42,.14);
}
.matrix-top{display:flex;justify-content:space-between;align-items:center;}
.matrix-label{font-size:9px;color:#9ca3af;font-weight:800;letter-spacing:1.7px;text-transform:uppercase;}
.matrix-title{font-size:18px;font-weight:800;letter-spacing:-.4px;}
.matrix-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;margin-top:36px;}
.mcell{height:36px;border:1px solid #293548;border-radius:6px;background:#172033;}
.mcell.on{background:#f8fafc;border-color:#f8fafc;}
.mcell.blue{background:#60a5fa;border-color:#60a5fa;}
.matrix-footer{
  position:absolute;left:24px;right:24px;bottom:20px;display:flex;justify-content:space-between;
  font-size:9px;color:#7f8a99;font-weight:700;letter-spacing:1.1px;text-transform:uppercase;
}

/* Sections and type */
.section-rule{margin-top:10px;padding-top:18px;border-top:1px solid var(--line);}
.section-kicker{font-size:9px;line-height:1;color:#9aa1ac;font-weight:800;letter-spacing:1.8px;text-transform:uppercase;}
.section-title{margin:8px 0;font-size:31px;line-height:1.08;letter-spacing:-1.2px;font-weight:750;color:#111827;}
.section-copy{max-width:820px;font-size:13px;line-height:1.65;color:#6b7280;}

/* Upload */
.upload-shell{
  margin-top:20px;padding:26px;border:1px solid #dbe1e8;border-radius:22px;
  background:linear-gradient(180deg,#fff 0%,#fbfcfe 100%);box-shadow:var(--shadow);
}
.upload-top{display:flex;align-items:flex-start;justify-content:space-between;gap:22px;}
.upload-number{font-size:9px;line-height:1;color:#9aa1ac;font-weight:800;letter-spacing:1.8px;text-transform:uppercase;}
.upload-big{margin-top:12px;font-size:26px;line-height:1.1;letter-spacing:-1px;font-weight:780;color:#111827;}
.upload-small{margin-top:6px;font-size:12px;color:#727b87;}
.upload-meta{
  padding:7px 9px;border:1px solid var(--line);border-radius:999px;background:#fff;
  color:#7b8490;font-size:9px;line-height:1;font-weight:750;letter-spacing:1.1px;
  text-transform:uppercase;white-space:nowrap;
}
[data-testid="stFileUploader"]{margin-top:18px !important;}
[data-testid="stFileUploaderDropzone"]{
  min-height:58px !important;padding:8px !important;
  border:1px dashed #c6ccd5 !important;border-radius:14px !important;
  background:#f9fafb !important;color:transparent !important;
}
[data-testid="stFileUploaderDropzone"]:hover{
  border-color:#9aa6b5 !important;background:#f7faff !important;
}
[data-testid="stFileUploaderDropzone"] > div{
  display:flex !important;align-items:center !important;gap:10px !important;padding:4px !important;
}
[data-testid="stFileUploaderDropzoneInstructions"],
[data-testid="stFileUploaderDropzone"] small{
  display:none !important;
}
[data-testid="stFileUploaderDropzone"] button{
  min-height:40px !important;padding:0 16px !important;border-radius:10px !important;
  border:0 !important;background:#111827 !important;color:#fff !important;
  font-size:12px !important;font-weight:750 !important;
}
[data-testid="stFileUploaderDropzone"] button *{
  color:#fff !important;
}
.upload-helper{
  display:flex;align-items:center;justify-content:flex-start;gap:10px;
  margin-top:8px;padding:0 2px;color:#89919d;font-size:11px;line-height:1.4;
}
.upload-helper strong{color:#596270;font-weight:700;}
.upload-helper span:last-child::before{
  content:"•"; margin-right:10px; color:#b0b6bf;
}

/* Data signals */
.signal-strip{
  display:grid;grid-template-columns:repeat(4,1fr);overflow:hidden;
  margin:34px 0 42px;border:1px solid var(--line);border-radius:18px;
  background:#fff;box-shadow:0 8px 24px rgba(17,24,39,.045);
}
.signal{min-width:0;padding:18px 20px;border-right:1px solid var(--line);}
.signal:last-child{border-right:0;}
.signal-label{font-size:9px;line-height:1;color:#9299a4;font-weight:800;letter-spacing:1.6px;text-transform:uppercase;}
.signal-value{margin-top:8px;font-size:30px;line-height:1;color:#111827;font-weight:800;letter-spacing:-1.7px;}
.signal-meta{margin-top:5px;color:#9aa1ac;font-size:10px;}

/* Recommendation rows */
.rec-row{
  display:grid;grid-template-columns:58px minmax(0,1fr) 180px;gap:18px;align-items:center;
  padding:19px 0;border-bottom:1px solid var(--line);
}
.rec-index{font-size:12px;color:#a0a7b1;font-weight:800;letter-spacing:1px;}
.rec-title{font-size:16px;line-height:1.2;color:#111827;font-weight:750;letter-spacing:-.25px;}
.rec-reason{max-width:740px;margin-top:5px;color:#6f7783;font-size:12px;line-height:1.55;}
.rec-tag{
  justify-self:end;padding:8px 10px;border:1px solid #d5d9df;border-radius:999px;
  color:#69727e;font-size:9px;line-height:1;font-weight:800;letter-spacing:1px;
  text-align:center;text-transform:uppercase;
}
.rec-tag.hot{border-color:#111827;background:#111827;color:#fff;}

/* Page headers */
.analysis-head{
  display:flex;align-items:flex-end;justify-content:space-between;gap:28px;
  padding:16px 0 20px;margin-bottom:22px;border-bottom:1px solid var(--line);
}
.analysis-head h1{
  margin:7px 0 0;color:#111827;font-size:clamp(38px,4.3vw,58px);
  line-height:1.02;font-weight:800;letter-spacing:-2.7px;
}
.analysis-meta{max-width:500px;color:#747d89;font-size:11px;line-height:1.6;text-align:right;}

/* Tabs and controls */
.stTabs [data-baseweb="tab-list"]{
  gap:5px;padding:4px;border:1px solid var(--line);border-radius:14px;background:#f1f3f6;
}
.stTabs [data-baseweb="tab"]{
  min-height:38px;padding:8px 14px !important;border-radius:10px !important;
  color:#757e89 !important;font-size:11px !important;font-weight:700 !important;
}
.stTabs [aria-selected="true"]{
  color:#111827 !important;background:#fff !important;box-shadow:0 3px 10px rgba(17,24,39,.06) !important;
}
div[data-baseweb="select"] > div,input,textarea{
  background:#fff !important;border:1px solid #d3d8df !important;border-radius:10px !important;
  box-shadow:none !important;
}
div[data-baseweb="select"] > div:focus-within,input:focus,textarea:focus{
  border-color:#93b4ff !important;box-shadow:0 0 0 3px rgba(37,99,235,.08) !important;
}
[data-testid="stMetric"]{
  border:1px solid var(--line) !important;border-radius:16px !important;background:#fff !important;
  padding:14px 16px !important;
}
[data-testid="stMetricValue"]{color:#111827 !important;font-size:27px !important;font-weight:800 !important;letter-spacing:-1.4px !important;}
[data-testid="stMetricLabel"]{color:#8a929d !important;font-size:9px !important;font-weight:800 !important;letter-spacing:1.3px !important;text-transform:uppercase !important;}
[data-testid="stDataFrame"]{overflow:hidden !important;border:1px solid var(--line) !important;border-radius:14px !important;background:#fff !important;}
.stDownloadButton > button{border-radius:10px !important;border:1px solid var(--line) !important;background:#fff !important;color:#374151 !important;font-weight:700 !important;}
button[kind="primary"]{background:#111827 !important;color:#fff !important;border-color:#111827 !important;}

/* Modules / comparison */
.module-line{padding:18px 0;border-bottom:1px solid var(--line);}
.module-line b{color:#111827;font-size:14px;font-weight:750;}
.module-line p{margin:5px 0 0;color:#707986;font-size:11px;line-height:1.55;}
.mini-heading{margin:28px 0 9px;color:#8a929d;font-size:9px;line-height:1;font-weight:800;letter-spacing:1.7px;text-transform:uppercase;}
.empty{padding:34px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line);color:#707986;font-size:13px;line-height:1.65;}
.dataset-shelf{
  display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 20px;padding-bottom:4px;border-bottom:1px solid var(--line);
}
.shelf-item{
  display:flex;align-items:center;gap:7px;padding:8px 10px;border:1px solid var(--line);
  border-radius:10px;background:#fff;color:#66707d;font-size:10px;
}
.shelf-item.active{border-color:#111827;background:#111827;color:#fff;}
.shelf-item small{color:#9aa1ac;font-size:9px;}
.shelf-item.active small{color:#d1d5db;}
.compare-head{
  display:grid;grid-template-columns:1fr 1fr;margin-bottom:0;padding:14px 16px;
  border-radius:14px 14px 0 0;background:#111827;color:#fff;font-size:10px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase;
}
.compare-head div:last-child{text-align:right;}
.compare-empty{padding:34px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line);margin-top:20px;}
.compare-empty-big{color:var(--blue);font-size:12px;font-weight:800;letter-spacing:1.3px;text-transform:uppercase;}
.compare-empty-title{margin-top:6px;color:#111827;font-size:28px;line-height:1.1;letter-spacing:-1px;font-weight:750;}
.compare-empty-copy{max-width:650px;margin-top:7px;color:#707986;font-size:12px;line-height:1.6;}
.workspace-note{
  margin-bottom:22px;padding:13px 15px;border:1px solid #dce5f5;border-radius:12px;
  background:var(--blue-soft);color:#49617d;font-size:11px;line-height:1.55;
}
.workspace-bar{
  min-height:58px;display:flex;align-items:center;padding:11px 14px;border:1px solid var(--line);
  border-radius:14px;background:#fff;
}
.workspace-label{color:#939aa4;font-size:8px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase;}
.workspace-file{
  margin-top:4px;overflow:hidden;color:#111827;font-size:13px;font-weight:750;
  text-overflow:ellipsis;white-space:nowrap;
}
.preview-card{
  overflow:hidden;margin-top:20px;border:1px solid var(--line);border-radius:18px;
  background:#fff;box-shadow:0 8px 25px rgba(17,24,39,.045);
}
.preview-head{
  display:flex;align-items:center;justify-content:space-between;gap:16px;padding:17px 18px;
  border-bottom:1px solid var(--line);
}
.preview-title{color:#111827;font-size:15px;font-weight:800;letter-spacing:-.2px;}
.preview-sub{margin-top:4px;color:#8a929d;font-size:10px;}
.preview-pill{
  max-width:42%;overflow:hidden;padding:7px 10px;border:1px solid var(--line);
  border-radius:999px;color:#6f7783;font-size:9px;font-weight:750;text-overflow:ellipsis;white-space:nowrap;
}
.quick-title{color:#111827;font-size:14px;font-weight:750;}
.quick-meta{margin-top:4px;color:#8a929d;font-size:10px;}

/* Footer */
.dn-footer{
  display:flex;justify-content:space-between;gap:18px;margin-top:62px;padding-top:14px;
  border-top:1px solid var(--line);color:#9aa1ac;font-size:9px;font-weight:700;
  letter-spacing:1px;text-transform:uppercase;
}

/* Responsive */
@media (max-width:1000px){
  .block-container{width:min(100% - 32px,920px) !important;}
  .hero-grid{grid-template-columns:1fr;gap:28px;}
  .matrix{min-height:260px;}
  .analysis-head{align-items:flex-start;flex-direction:column;}
  .analysis-meta{max-width:720px;text-align:left;}
  .rec-row{grid-template-columns:46px minmax(0,1fr);}
  .rec-tag{grid-column:2;justify-self:start;}
}
@media (max-width:720px){
  .block-container{width:calc(100% - 24px) !important;padding:12px 0 52px !important;}
  .nova-header{min-height:60px;padding:10px 11px;margin-bottom:18px;border-radius:16px;}
  .nova-mark{width:36px;height:36px;border-radius:11px;}
  .nova-name{font-size:17px;}
  .nova-sub{font-size:8px;letter-spacing:1.4px;}
  .nova-status{padding:7px 9px;font-size:8px;}
  [data-testid="stHorizontalBlock"]{row-gap:8px !important;}
  [data-testid="stButton"] > button{min-height:40px !important;font-size:11px !important;padding:0 8px !important;}
  .hero-grid{margin:28px 0 34px;}
  .hero-title{font-size:clamp(42px,12vw,58px);line-height:1;letter-spacing:-2.7px;}
  .hero-copy{font-size:13px;}
  .matrix{padding:18px;min-height:220px;border-radius:18px;}
  .matrix-grid{gap:4px;margin-top:24px;}
  .mcell{height:27px;border-radius:4px;}
  .matrix-footer{left:18px;right:18px;bottom:15px;font-size:7px;}
  .section-title{font-size:27px;}
  .upload-shell{padding:18px;border-radius:18px;}
  .upload-top{flex-direction:column;gap:12px;}
  .upload-meta{align-self:flex-start;}
  .upload-big{font-size:23px;}
  .upload-helper{flex-direction:column;align-items:flex-start;gap:4px;}
  .signal-strip{grid-template-columns:1fr 1fr;border-radius:14px;}
  .signal{padding:14px;border-right:1px solid var(--line);border-bottom:1px solid var(--line);}
  .signal:nth-child(2n){border-right:0;}
  .signal:nth-last-child(-n+2){border-bottom:0;}
  .signal-value{font-size:25px;}
  .analysis-head{margin-bottom:18px;padding-top:8px;}
  .analysis-head h1{font-size:38px;letter-spacing:-1.8px;}
  .preview-head{align-items:flex-start;flex-direction:column;}
  .preview-pill{max-width:100%;}
  .dataset-shelf{flex-wrap:nowrap;overflow-x:auto;padding-bottom:8px;}
  .shelf-item{flex:0 0 auto;}
  .compare-head{grid-template-columns:1fr;gap:6px;}
  .compare-head div:last-child{text-align:left;}
  .dn-footer{flex-direction:column;gap:6px;}
  [data-testid="stFileUploaderDropzone"]{min-height:62px !important;}
  [data-testid="stFileUploaderDropzone"] > div{flex-wrap:wrap !important;}
  .upload-helper{gap:6px;flex-wrap:wrap;}
  .upload-helper span:last-child::before{margin-right:6px;}
}
@media (max-width:420px){
  .block-container{width:calc(100% - 18px) !important;}
  .nova-status span:last-child{display:none;}
  .nova-status{width:10px;min-width:10px;padding:8px;border:0;background:transparent;}
  .hero-title{font-size:40px;}
  .section-title{font-size:25px;}
  .signal-label{font-size:8px;}
  .signal-value{font-size:22px;}
}
</style>''', unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# Session state
# -----------------------------------------------------------------------------
if "df" not in st.session_state:
    st.session_state.df = None
if "dataset_name" not in st.session_state:
    st.session_state.dataset_name = ""
if "profile" not in st.session_state:
    st.session_state.profile = None
if "datasets" not in st.session_state:
    st.session_state.datasets = {}
if "active_dataset" not in st.session_state:
    st.session_state.active_dataset = ""
if "page" not in st.session_state:
    st.session_state.page = "Overview"
if "processed_uploads" not in st.session_state:
    st.session_state.processed_uploads = set()


def header():
    dataset_state = (
        f"{len(st.session_state.datasets)} dataset{'s' if len(st.session_state.datasets) != 1 else ''}"
        if st.session_state.datasets else "Ready for data"
    )
    st.markdown(
        f'''<div class="nova-header">
            <div class="nova-brand">
                <div class="nova-mark">✦</div>
                <div>
                    <div class="nova-name">Nova</div>
                    <div class="nova-sub">Data Intelligence Studio</div>
                </div>
            </div>
            <div class="nova-status"><span class="nova-dot"></span><span>{dataset_state}</span></div>
        </div>''',
        unsafe_allow_html=True,
    )


def _upload_key(uploaded):
    size = getattr(uploaded, "size", len(uploaded.getvalue()))
    return f"{uploaded.name}|{size}"


def _unique_dataset_name(name):
    if name not in st.session_state.datasets:
        return name
    stem, dot, ext = name.rpartition(".")
    if not dot:
        stem, ext = name, ""
    i = 2
    while True:
        candidate = f"{stem} ({i})" + (f".{ext}" if ext else "")
        if candidate not in st.session_state.datasets:
            return candidate
        i += 1


def load_data(uploaded_files, auto_route=False):
    if not uploaded_files:
        return 0
    if not isinstance(uploaded_files, list):
        uploaded_files = [uploaded_files]
    added = 0
    errors = []
    for uploaded in uploaded_files:
        key = _upload_key(uploaded)
        if key in st.session_state.processed_uploads:
            continue
        try:
            df = load_uploaded_file(uploaded)
            if df.empty or len(df.columns) == 0:
                raise ValueError("The file contains no usable rows or columns.")
            display_name = _unique_dataset_name(uploaded.name)
            st.session_state.datasets[display_name] = {"df": df, "profile": profile_dataset(df)}
            st.session_state.processed_uploads.add(key)
            st.session_state.active_dataset = display_name
            added += 1
        except Exception as exc:
            errors.append(f"{uploaded.name}: {exc}")
    if added:
        active = st.session_state.datasets[st.session_state.active_dataset]
        st.session_state.df = active["df"]
        st.session_state.dataset_name = st.session_state.active_dataset
        st.session_state.profile = active["profile"]
        if auto_route:
            st.session_state.page = "Dataset"
            st.session_state._just_uploaded = True
            st.rerun()
    for err in errors:
        st.error(f"Nova could not read this file: {err}")
    return added


def activate_dataset(name):
    if name not in st.session_state.datasets:
        return
    item = st.session_state.datasets[name]
    st.session_state.active_dataset = name
    st.session_state.df = item["df"]
    st.session_state.dataset_name = name
    st.session_state.profile = item["profile"]


def remove_dataset(name):
    if name in st.session_state.datasets:
        del st.session_state.datasets[name]
    remaining = list(st.session_state.datasets.keys())
    if remaining:
        activate_dataset(remaining[0])
    else:
        st.session_state.df = None
        st.session_state.profile = None
        st.session_state.dataset_name = ""
        st.session_state.active_dataset = ""


def current_profile():
    return st.session_state.profile or profile_dataset(st.session_state.df)


def has_data():
    return st.session_state.df is not None


def upload_control(label, key, multiple=True):
    uploaded = st.file_uploader(
        label,
        type=["csv", "xlsx", "xls"],
        accept_multiple_files=multiple,
        label_visibility="collapsed",
        key=key,
    )
    st.markdown(
        '<div class="upload-helper"><span><strong>Up to 200 MB per file</strong></span>'
        '<span>CSV · XLSX · XLS</span></div>',
        unsafe_allow_html=True,
    )
    return uploaded


def nav():
    options = ["Overview", "Dataset", "Compare", "Business", "AI Lab", "Academic"]
    st.markdown('<div class="nav-wrap"><div class="nav-caption">Workspace</div>', unsafe_allow_html=True)
    cols = st.columns(6, gap="small")
    for i, option in enumerate(options):
        with cols[i]:
            if st.button(option, key=f"nav_{option.replace(' ', '_')}", type="primary" if st.session_state.page == option else "secondary", use_container_width=True):
                if option != st.session_state.page:
                    st.session_state.page = option
                    st.rerun()
    st.markdown('</div>', unsafe_allow_html=True)


def recommendation_rows(recs, limit=None):
    recs = recs if limit is None else recs[:limit]
    for i, rec in enumerate(recs, 1):
        hot = rec["status"] == "Recommended"
        st.markdown(
            f'''<div class="rec-row">
              <div class="rec-index">{i:02d}</div>
              <div><div class="rec-title">{rec['title']}</div><div class="rec-reason">{rec['reason']}</div></div>
              <div class="rec-tag {'hot' if hot else ''}">{rec['area']} · {rec['status']}</div>
            </div>''',
            unsafe_allow_html=True,
        )


def page_intro(kicker, title, copy):
    st.markdown(
        f'''<div class="analysis-head">
            <div><div class="section-kicker">{kicker}</div><h1>{title}</h1></div>
            <div class="analysis-meta">{copy}</div>
        </div>''',
        unsafe_allow_html=True,
    )


header()
nav()

# -----------------------------------------------------------------------------
# OVERVIEW
# -----------------------------------------------------------------------------
if st.session_state.page == "Overview":
    st.markdown(
        '''<div class="hero-grid">
            <div>
              <div class="hero-kicker">One workspace · AI + Applied Business</div>
              <div class="hero-title">Data should<br><em>answer back.</em></div>
              <div class="hero-copy">Drop in a dataset and Nova does the boring part first: understanding its shape, signals and limitations. Then it opens the analyses that actually fit.</div>
              <div class="hero-note">A focused workflow for your syllabus: describe → relate → test → model → decide.</div>
            </div>
            <div class="matrix">
              <div class="matrix-top"><div class="matrix-label">Signal map / live canvas</div><div class="matrix-title">NV.01</div></div>
              <div class="matrix-grid">'''
        + ''.join(f'<div class="mcell {"blue" if i in [3,10,17,18,25,31,38,39,46] else "on" if i%5==0 else ""}"></div>' for i in range(49))
        + '''</div><div class="matrix-footer"><span>structure</span><span>relationships</span><span>decision</span></div>
            </div>
        </div>''',
        unsafe_allow_html=True,
    )

    left, right = st.columns([1.35, .65], gap="large")
    with left:
        st.markdown('<div class="section-rule"><div class="section-kicker">01 · Import</div><div class="section-title">Start with the file, not the menu.</div><div class="section-copy">CSV and Excel are supported. The workspace profiles columns, detects data types, counts missing values and duplicates, and uses that information to guide the next step.</div></div>', unsafe_allow_html=True)
        st.markdown('<div class="upload-shell"><div class="upload-top"><div><div class="upload-number">Drop zone</div><div class="upload-big">Choose a dataset.</div><div class="upload-small">Your file stays inside this local Python session.</div></div><div class="upload-meta">CSV · XLSX · XLS</div></div>', unsafe_allow_html=True)
        uploaded = upload_control("Upload dataset", "overview_uploader", multiple=True)
        st.markdown('</div>', unsafe_allow_html=True)
        if uploaded:
            added = load_data(uploaded, auto_route=True)
            if added:
                st.success(f"{added} dataset(s) added. Nova opened the Dataset workspace automatically.")
    with right:
        st.markdown('<div class="section-rule"><div class="section-kicker">02 · The idea</div><div class="section-title">Less interface. More signal.</div><div class="section-copy">There are dozens of syllabus topics, but not every dataset can support every one. Nova keeps the interface calm and routes the user to operations the data can support.</div></div>', unsafe_allow_html=True)
        for n, title, body in [
            ("01", "Ingest", "Bring in CSV or Excel."),
            ("02", "Understand", "Read structure and quality."),
            ("03", "Recommend", "Surface compatible analysis."),
            ("04", "Decide", "Explore evidence and models."),
        ]:
            st.markdown(f'<div class="module-line"><b>{n} · {title}</b><p>{body}</p></div>', unsafe_allow_html=True)

    if has_data():
        df = st.session_state.df
        p = current_profile()
        h = dataset_health(df)
        st.markdown('<div class="signal-strip">' +
                    ''.join([
                        f'<div class="signal"><div class="signal-label">Rows</div><div class="signal-value">{len(df):,}</div><div class="signal-meta">records in file</div></div>',
                        f'<div class="signal"><div class="signal-label">Fields</div><div class="signal-value">{len(df.columns):,}</div><div class="signal-meta">columns detected</div></div>',
                        f'<div class="signal"><div class="signal-label">Numeric</div><div class="signal-value">{len(p["numeric_columns"]):,}</div><div class="signal-meta">analysis-ready</div></div>',
                        f'<div class="signal"><div class="signal-label">Missing</div><div class="signal-value">{h["missing_cells"]:,}</div><div class="signal-meta">empty cells</div></div>',
                    ]) + '</div>', unsafe_allow_html=True)
        st.markdown('<div class="section-rule"><div class="section-kicker">03 · Next moves</div><div class="section-title">What the data can support.</div></div>', unsafe_allow_html=True)
        recommendation_rows(recommend_analyses(df, p), 8)
        st.markdown('<div class="section-rule"><div class="section-title">A first look.</div><div class="section-copy">The first ten rows, before any transformations.</div></div>', unsafe_allow_html=True)
        st.dataframe(df.head(10), use_container_width=True, height=310, hide_index=True)
    else:
        st.markdown('<div class="section-rule"><div class="section-kicker">04 · Ready state</div><div class="section-title">Nothing is hidden behind a wall of controls.</div><div class="empty">Once a dataset is loaded, Nova will open its live signals, recommendations, charts, statistics and AI routes here.</div></div>', unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# DATASET
# -----------------------------------------------------------------------------
elif st.session_state.page == "Dataset":
    if not has_data():
        page_intro("Dataset", "Bring a dataset in.", "Upload a CSV or Excel file to open the dataset workspace.")
        st.markdown('<div class="empty"><strong>No dataset loaded.</strong><br>Go to Overview and import a CSV or Excel file.</div>', unsafe_allow_html=True)
    else:
        df = st.session_state.df
        p = current_profile(); h = dataset_health(df)
        page_intro("Dataset / 01", "Know your data.", f"{st.session_state.dataset_name} · {len(df):,} rows · {len(df.columns):,} fields")

        if st.session_state.pop("_just_uploaded", False):
            st.success(f"{st.session_state.dataset_name} loaded successfully. Your data is ready below.")

        names = list(st.session_state.datasets.keys())
        left, right = st.columns([1.7, 1], gap="medium")
        with left:
            st.markdown(f'<div class="workspace-bar"><div><div class="workspace-label">Active dataset</div><div class="workspace-file">{st.session_state.dataset_name}</div></div></div>', unsafe_allow_html=True)
        with right:
            if names:
                chosen = st.selectbox("Switch dataset", names, index=names.index(st.session_state.active_dataset), label_visibility="collapsed", key="active_dataset_selector")
                if chosen != st.session_state.active_dataset:
                    activate_dataset(chosen)
                    st.rerun()

        st.markdown('<div class="dataset-shelf">' + ''.join(
            f'<div class="shelf-item {"active" if n == st.session_state.active_dataset else ""}"><span>{"●" if n == st.session_state.active_dataset else "○"}</span>{n}<small>{len(st.session_state.datasets[n]["df"]):,} rows</small></div>'
            for n in names
        ) + '</div>', unsafe_allow_html=True)

        st.markdown(
            f'''<div class="preview-card">
                <div class="preview-head">
                    <div><div class="preview-title">Dataset preview</div><div class="preview-sub">First 12 rows · {len(df):,} total records · {len(df.columns):,} fields</div></div>
                    <div class="preview-pill">{st.session_state.dataset_name}</div>
                </div>''',
            unsafe_allow_html=True,
        )
        st.dataframe(df.head(12), use_container_width=True, height=390, hide_index=True)
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="signal-strip">' + ''.join([
            f'<div class="signal"><div class="signal-label">Rows</div><div class="signal-value">{len(df):,}</div><div class="signal-meta">records</div></div>',
            f'<div class="signal"><div class="signal-label">Fields</div><div class="signal-value">{len(df.columns):,}</div><div class="signal-meta">columns</div></div>',
            f'<div class="signal"><div class="signal-label">Missing</div><div class="signal-value">{h["missing_cells"]:,}</div><div class="signal-meta">empty cells</div></div>',
            f'<div class="signal"><div class="signal-label">Duplicates</div><div class="signal-value">{h["duplicate_rows"]:,}</div><div class="signal-meta">exact matches</div></div>',
        ]) + '</div>', unsafe_allow_html=True)

        c1, c2 = st.columns([1.2, 1], gap="large")
        with c1:
            st.markdown('<div class="quick-title">Add another dataset for comparison</div><div class="quick-meta">CSV, XLSX or XLS · multiple files supported</div>', unsafe_allow_html=True)
        with c2:
            more_files = upload_control("Add more datasets", "dataset_multi_uploader", multiple=True)
            if more_files:
                added = load_data(more_files, auto_route=False)
                if added:
                    st.rerun()

        t1, t2, t3 = st.tabs(["Preview", "Field profile", "Quality"])
        with t1:
            st.download_button("Export current dataset", df.to_csv(index=False).encode(), "nova_data.csv", "text/csv")
            st.dataframe(df, use_container_width=True, height=520, hide_index=True)
        with t2:
            rows=[{"Field":c,"Type":p["types"].get(c,str(df[c].dtype)),"Unique":int(df[c].nunique(dropna=True)),"Missing":int(df[c].isna().sum())} for c in df.columns]
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True, height=480)
        with t3:
            st.markdown('<div class="mini-heading">Missing values by field</div>', unsafe_allow_html=True)
            miss=df.isna().sum().sort_values(ascending=False)
            st.dataframe(miss[miss>0].rename("Missing cells"), use_container_width=True)
            st.markdown('<div class="mini-heading">Numerical description</div>', unsafe_allow_html=True)
            if p["numeric_columns"]:
                st.dataframe(df[p["numeric_columns"]].describe().T, use_container_width=True)
            else:
                st.info("No numerical fields detected.")

# -----------------------------------------------------------------------------
# COMPARE
# -----------------------------------------------------------------------------
elif st.session_state.page == "Compare":
    if len(st.session_state.datasets) < 2:
        page_intro("Compare", "See datasets side by side.", "Load at least two CSV or Excel datasets from Overview or Dataset to unlock comparison.")
        st.markdown(
            '<div class="compare-empty"><div class="compare-empty-big">01 + 02</div><div class="compare-empty-title">Two datasets. One view.</div><div class="compare-empty-copy">Compare row counts, fields and shared numerical variables without replacing your original files.</div></div>',
            unsafe_allow_html=True,
        )
    else:
        names = list(st.session_state.datasets.keys())
        page_intro("Compare", "Put the data side by side.", "Choose two loaded datasets and compare structure, quality and shared numerical measures in one view.")
        c1, c2 = st.columns(2, gap="large")
        with c1:
            left_name = st.selectbox("Dataset A", names, index=0, key="compare_a")
        with c2:
            right_index = 1 if names[1] != left_name else 0
            right_name = st.selectbox("Dataset B", names, index=right_index, key="compare_b")
        if left_name == right_name:
            st.warning("Choose two different datasets to compare.")
        else:
            left = st.session_state.datasets[left_name]
            right = st.session_state.datasets[right_name]
            ldf, rdf = left["df"], right["df"]
            lp, rp = left["profile"], right["profile"]
            lh, rh = dataset_health(ldf), dataset_health(rdf)

            st.markdown('<div class="compare-head"><div>A · '+left_name+'</div><div>B · '+right_name+'</div></div>', unsafe_allow_html=True)
            comparison_rows = [
                ("Rows", len(ldf), len(rdf)),
                ("Fields", len(ldf.columns), len(rdf.columns)),
                ("Numerical fields", len(lp["numeric_columns"]), len(rp["numeric_columns"])),
                ("Categorical fields", len(lp["categorical_columns"]), len(rp["categorical_columns"])),
                ("Date fields", len(lp["date_columns"]), len(rp["date_columns"])),
                ("Missing cells", lh["missing_cells"], rh["missing_cells"]),
                ("Duplicate rows", lh["duplicate_rows"], rh["duplicate_rows"]),
            ]
            cmp_df = pd.DataFrame(comparison_rows, columns=["Signal", "Dataset A", "Dataset B"])
            st.dataframe(cmp_df, use_container_width=True, hide_index=True)

            shared = sorted(set(lp["numeric_columns"]).intersection(rp["numeric_columns"]))
            if shared:
                st.markdown('<div class="mini-heading">Shared numerical fields</div>', unsafe_allow_html=True)
                field = st.selectbox("Compare a numerical field", shared, key="compare_field")
                rows=[]
                for label, data in [(left_name, ldf[field]), (right_name, rdf[field])]:
                    x=pd.to_numeric(data, errors="coerce").dropna()
                    rows.append({
                        "Dataset": label,
                        "Count": int(x.size),
                        "Mean": float(x.mean()) if len(x) else float("nan"),
                        "Median": float(x.median()) if len(x) else float("nan"),
                        "Std. Dev.": float(x.std()) if len(x) > 1 else float("nan"),
                        "Minimum": float(x.min()) if len(x) else float("nan"),
                        "Maximum": float(x.max()) if len(x) else float("nan"),
                    })
                stat_df=pd.DataFrame(rows)
                st.dataframe(stat_df.round(3), use_container_width=True, hide_index=True)
                chart_df=pd.DataFrame({left_name: pd.to_numeric(ldf[field],errors="coerce").dropna().reset_index(drop=True), right_name: pd.to_numeric(rdf[field],errors="coerce").dropna().reset_index(drop=True)})
                st.line_chart(chart_df, height=260)
            else:
                st.markdown('<div class="compare-empty"><div class="compare-empty-title">No shared numerical fields detected.</div><div class="compare-empty-copy">The datasets can still be compared structurally above. Choose files with common numerical columns for metric comparison.</div></div>', unsafe_allow_html=True)

            st.markdown('<div class="mini-heading">Common columns</div>', unsafe_allow_html=True)
            common_cols = sorted(set(ldf.columns).intersection(rdf.columns))
            if common_cols:
                st.dataframe(pd.DataFrame({"Common field": common_cols}), use_container_width=True, hide_index=True)
            else:
                st.caption("No column names are shared between the selected datasets.")

# -----------------------------------------------------------------------------
# BUSINESS
# -----------------------------------------------------------------------------
elif st.session_state.page == "Business":
    if not has_data():
        page_intro("Business Analytics", "Business starts with evidence.", "Load a dataset first. Nova will then expose the operations that match its fields.")
        st.markdown('<div class="empty">No dataset loaded. Return to Overview.</div>', unsafe_allow_html=True)
    else:
        df=st.session_state.df; p=current_profile()
        page_intro("Business Analytics", "Measure. Relate. Test. Forecast.", "Applied Business Analytics features are grouped by purpose rather than by syllabus chapter number.")
        tabs=st.tabs(["Describe","Visualize","Probability","Test","Forecast","Decide"])
        with tabs[0]:
            if p["numeric_columns"]:
                field=st.selectbox("Numerical field",p["numeric_columns"])
                st.dataframe(descriptive_statistics(df[field]),use_container_width=True,hide_index=True)
                s=df[field].dropna()
                st.line_chart(s.reset_index(drop=True), height=220)
            else: st.info("A numerical field is required.")
        with tabs[1]:
            kind=st.selectbox("Chart",["Bar","Line","Pie","Histogram","Box Plot","Scatter","Area","Heatmap"])
            cols=list(df.columns); nums=p["numeric_columns"]
            x=st.selectbox("Horizontal / category",cols)
            y=st.selectbox("Value",cols,index=cols.index(nums[0]) if nums else 0)
            try: st.plotly_chart(build_chart(df,kind,x,y),use_container_width=True)
            except Exception as exc: st.error(str(exc))
            if len(nums)>=2:
                st.markdown('<div class="mini-heading">Correlation</div>',unsafe_allow_html=True)
                st.dataframe(df[nums].corr(numeric_only=True).round(3),use_container_width=True)
                rx=st.selectbox("Regression predictor",nums,key="rx")
                ry=st.selectbox("Regression target",[c for c in nums if c!=rx],key="ry")
                rr=regression_model(df,rx,ry)
                st.json(rr["summary"])
                st.plotly_chart(rr["figure"],use_container_width=True)
        with tabs[2]:
            c1,c2=st.columns(2,gap="large")
            with c1:
                rolls=st.slider("Dice rolls",100,10000,1000,100)
                face=st.slider("Target face",1,6,6)
                dr=dice_simulation(rolls,face)
                st.metric("Estimated probability",f"{dr['estimated']:.3f}")
                st.bar_chart(dr["counts"])
            with c2:
                n=st.slider("Binomial trials",1,100,20)
                pp=st.slider("Success probability",0.01,0.99,0.50,0.01)
                br=binomial_simulation(n,pp,1200)
                st.metric("Expected successes",f"{br['expected']:.2f}")
                st.line_chart(br["distribution"])
            dist=st.selectbox("Continuous distribution",["Normal","Uniform","Exponential"])
            st.plotly_chart(distribution_simulation(dist,2000),use_container_width=True)
        with tabs[3]:
            nums=p["numeric_columns"]
            if nums:
                f=st.selectbox("Field",nums,key="test_field")
                level=st.select_slider("Confidence level",options=[.90,.95,.99],value=.95)
                ci=confidence_interval(df[f].dropna(),level)
                st.write(f"**{int(level*100)}% interval:** ({ci['lower']:.4f}, {ci['upper']:.4f})")
                if len(df[f].dropna())>=10:
                    boot=bootstrap_confidence_interval(df[f].dropna(),level)
                    st.write(f"**Bootstrap interval:** ({boot['lower']:.4f}, {boot['upper']:.4f})")
                sample_size=st.slider("Sampling size",2,max(2,min(100,len(df[f].dropna()))),min(20,max(2,len(df[f].dropna())//3)))
                sample=sample_series(df[f].dropna(),sample_size)
                st.metric("Population mean",f"{sample['population_mean']:.3f}")
                st.metric("Sampling standard error",f"{sample['standard_error']:.3f}")
                mu=st.number_input("Hypothesized mean",value=float(df[f].dropna().mean()))
                st.json(hypothesis_test(df[f].dropna(),mu))
            if len(nums)>=2:
                st.markdown('<div class="mini-heading">A / B test</div>',unsafe_allow_html=True)
                a=st.selectbox("Group A",nums,key="ab1")
                b=st.selectbox("Group B",[x for x in nums if x!=a],key="ab2")
                st.json(ab_test(df[a].dropna(),df[b].dropna()))
            if p["categorical_columns"] and nums:
                st.markdown('<div class="mini-heading">ANOVA</div>',unsafe_allow_html=True)
                g=st.selectbox("Grouping field",p["categorical_columns"],key="ag")
                v=st.selectbox("Outcome field",nums,key="av")
                st.json(anova_test(df,g,v))
        with tabs[4]:
            if p["date_columns"] and p["numeric_columns"]:
                d=st.selectbox("Date field",p["date_columns"])
                v=st.selectbox("Measure",p["numeric_columns"])
                ts=time_series_analysis(df,d,v)
                st.plotly_chart(ts["figure"],use_container_width=True)
                st.dataframe(ts["data"].tail(20),use_container_width=True,hide_index=True)
                h=st.slider("Forecast periods",1,30,7)
                try:
                    fc=forecast_series(ts["data"],h)
                    st.plotly_chart(fc["figure"],use_container_width=True)
                    st.caption(f"Forecast method: {fc['model']}")
                except Exception as exc:
                    st.info(f"Forecast preview is unavailable for this dataset yet. {exc}")
            else: st.info("Forecasting needs a date field and a numerical field.")
        with tabs[5]:
            st.markdown('<div class="mini-heading">Expected value</div>',unsafe_allow_html=True)
            names=st.text_area("Decision names", "Launch Product\nDo Not Launch\nRun Pilot").splitlines()
            probs=st.text_input("Scenario probabilities","0.5,0.3,0.2")
            payoffs=st.text_input("Payoff rows","100,50,-10;20,80,10;60,60,30")
            try:
                pv=[float(x.strip()) for x in probs.split(',') if x.strip()]
                rows=[[float(x.strip()) for x in r.split(',') if x.strip()] for r in payoffs.split(';')]
                if names and rows and len(names)==len(rows) and len(pv)==len(rows[0]):
                    st.dataframe(expected_value_analysis(names,pv,rows),use_container_width=True,hide_index=True)
            except Exception: st.caption("Enter compatible numeric values.")
            st.markdown('<div class="mini-heading">Inventory simulation</div>',unsafe_allow_html=True)
            units=st.slider("Starting inventory",10,500,100)
            demand=st.slider("Average daily demand",1,100,20)
            days=st.slider("Days",10,365,60)
            ir=inventory_simulation(units,demand,days)
            st.plotly_chart(ir["figure"],use_container_width=True)
            st.json(ir["summary"])
            st.markdown('<div class="mini-heading">Optimization teaching example</div>',unsafe_allow_html=True)
            st.json(linear_programming_demo())

# -----------------------------------------------------------------------------
# AI LAB
# -----------------------------------------------------------------------------
elif st.session_state.page == "AI Lab":
    page_intro("AI Lab", "Teach the system to think.", "Small, explainable demonstrations connect AI foundations to a real uploaded dataset when one is available.")
    tabs=st.tabs(["Agent","Search","Learning","Ethics"])
    with tabs[0]:
        size=st.slider("Grid size",4,10,6)
        st.dataframe(pd.DataFrame(agent_demo(size)),use_container_width=True,hide_index=True)
    with tabs[1]:
        alg=st.selectbox("Search algorithm",["BFS","DFS","A*"])
        r=search_demo(alg)
        st.markdown(f"**Visited:** {' → '.join(r['visited'])}")
        st.markdown(f"**Path:** {' → '.join(r['path'])}")
    with tabs[2]:
        if not has_data():
            st.info("Load a dataset from Overview to use Learning from Examples.")
        else:
            df=st.session_state.df;p=current_profile(); nums=p["numeric_columns"];cats=p["categorical_columns"]
            task=st.selectbox("Model",["Classification","Decision Tree","Linear Regression"])
            if task in ["Classification","Decision Tree"]:
                if not cats: st.warning("A categorical target is recommended.")
                features=st.multiselect("Features",list(df.columns),default=nums[:min(3,len(nums))])
                target=st.selectbox("Target",list(df.columns))
                if st.button("Run model",type="primary"):
                    try:
                        r=(classification_model(df,features,target) if task=="Classification" else decision_tree_model(df,features,target))
                        st.metric("Accuracy",f"{r['accuracy']:.1%}")
                        st.dataframe(r["report"],use_container_width=True,hide_index=True)
                        st.caption(r["explanation"])
                    except Exception as exc: st.error(str(exc))
            else:
                if len(nums)>=2:
                    x=st.selectbox("Predictor",nums)
                    y=st.selectbox("Target",[c for c in nums if c!=x])
                    if st.button("Run regression",type="primary"):
                        r=regression_model(df,x,y)
                        st.json(r["summary"])
                        st.plotly_chart(r["figure"],use_container_width=True)
    with tabs[3]:
        for title,body in [
            ("Bias","Training data can carry historical or sampling bias into model outputs."),
            ("Fairness","Evaluate relevant groups when model decisions affect people."),
            ("Privacy","Process only the data needed and avoid exposing sensitive records."),
            ("Transparency","Show inputs, assumptions and limitations alongside important results."),
            ("Safety","Treat uncertain model outputs as evidence, not unquestionable truth."),
            ("Security","Keep uploaded files local and never hard-code secrets."),
        ]:
            st.markdown(f'<div class="module-line"><b>{title}</b><p>{body}</p></div>',unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# ACADEMIC
# -----------------------------------------------------------------------------
elif st.session_state.page == "Academic":
    page_intro("Academic map", "Your syllabus, wired into the product.", "This page makes the project easy to defend in a viva by mapping a syllabus concept to a concrete product feature.")
    mapping=pd.DataFrame([
        ["AI","Introduction","Overall Nova workflow"],
        ["AI","Intelligent Agents","Grid-world agent demonstration"],
        ["AI","Solving Problems by Searching","BFS, DFS and A*"],
        ["AI","Quantifying Uncertainty","Probability + interval tools"],
        ["AI","Probabilistic Reasoning","Probability demonstrations"],
        ["AI","Learning from Examples","Train/test modelling workflow"],
        ["AI","Classification","Classification model"],
        ["AI","Decision Trees","Decision-tree model"],
        ["AI","Philosophy, Ethics and Safety","Bias, fairness, privacy, transparency, safety"],
        ["Applied Business","Introduction to Business Analytics","Dataset profiling + business observations"],
        ["Applied Business","Distribution of a Variable","Descriptive statistics + charts"],
        ["Applied Business","Finding Relationships Among Variables","Correlation + regression"],
        ["Applied Business","Business Intelligence Tools","Dashboard-style analysis workspace"],
        ["Applied Business","Probability and Probability Distributions","Dice, binomial and continuous distribution simulations"],
        ["Applied Business","Decision Making Under Uncertainty","Expected value + simulation"],
        ["Applied Business","Sampling and Sampling Distributions","Sampling distribution demonstration"],
        ["Applied Business","Confidence Interval Estimation","Confidence intervals + bootstrap"],
        ["Applied Business","Hypothesis Testing","One-sample test + A/B test"],
        ["Applied Business","Regression and Time Series Analysis","Regression + forecast"],
        ["Applied Business","Optimization and Simulation Modeling","Inventory + optimization example"],
        ["Applied Business","Analysis of Variance and Experimental Design","ANOVA"],
    ],columns=["Subject","Syllabus concept","Implemented feature"])
    st.dataframe(mapping,use_container_width=True,height=640,hide_index=True)

st.markdown('<div class="dn-footer"><span>Nova · Data Intelligence Studio</span><span>AI Foundations + Applied Business Analytics</span></div>',unsafe_allow_html=True)
