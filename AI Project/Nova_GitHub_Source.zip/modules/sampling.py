import numpy as np
import pandas as pd


def sample_series(series, sample_size, repeats=500):
    x = pd.to_numeric(series, errors='coerce').dropna().to_numpy()
    if len(x) < sample_size:
        raise ValueError('Sample size cannot exceed the number of available observations.')
    rng = np.random.default_rng(42)
    samples = rng.choice(x, size=(repeats, sample_size), replace=True)
    means = samples.mean(axis=1)
    return {
        'population_mean': float(x.mean()),
        'sample_means': pd.Series(means, name='Sample Mean'),
        'sample_mean': float(means[0]),
        'standard_error': float(means.std(ddof=1)),
        'population_size': int(len(x)),
    }
