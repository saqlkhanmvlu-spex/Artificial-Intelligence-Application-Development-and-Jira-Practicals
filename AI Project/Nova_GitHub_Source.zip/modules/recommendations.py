def recommend_analyses(df,profile):
    n=len(df); num=profile['numeric_columns']; cat=profile['categorical_columns']; dates=profile['date_columns']; text=profile['text_columns']; recs=[]
    if num:
        recs += [{'area':'Business Analytics','title':'Descriptive Statistics','reason':f'{len(num)} numerical column(s) detected. Mean, median, mode, variance, standard deviation and quartiles can be calculated.','status':'Recommended'},{'area':'Business Analytics','title':'Distribution Analysis','reason':'Numerical variables can be explored using histograms and box plots to study spread, outliers and shape.','status':'Recommended'}]
    if len(num)>=2: recs.append({'area':'Business Analytics','title':'Correlation & Regression','reason':'Multiple numerical variables are available, making relationships between variables measurable.','status':'Recommended'})
    if cat and num: recs.append({'area':'Business Analytics','title':'Group Comparison / ANOVA','reason':'The dataset contains both categorical groups and numerical outcomes.','status':'Recommended'})
    if dates and num: recs.append({'area':'Business Analytics','title':'Time-Series Analysis','reason':'A date/time field and numerical measure were detected, so trend analysis and forecasting are possible.','status':'Recommended'})
    if len(num)>=2 and n>=20: recs.append({'area':'AI','title':'Learning from Examples','reason':f'The dataset has {n:,} rows and multiple numerical variables, suitable for a train/test modelling workflow.','status':'Recommended'})
    if cat and num and n>=20: recs.append({'area':'AI','title':'Classification / Decision Tree','reason':'A categorical variable can act as a potential target and numerical variables can be used as features.','status':'Recommended'})
    if n>=10: recs.append({'area':'Business Analytics','title':'Sampling & Confidence Intervals','reason':'The dataset is large enough to demonstrate sampling, confidence interval estimation and bootstrap resampling.','status':'Recommended'})
    recs.append({'area':'AI','title':'Probability & Uncertainty','reason':'Probability simulations and uncertainty measures are available regardless of the dataset schema.','status':'Available'})
    if text: recs.append({'area':'AI','title':'Text Exploration','reason':f'{len(text)} high-cardinality text column(s) detected; inspect them before choosing a predictive target.','status':'Available'})
    return recs
