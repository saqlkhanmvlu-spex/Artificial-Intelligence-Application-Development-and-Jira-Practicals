import pandas as pd
import plotly.express as px


def build_chart(df, chart_type, x_col, y_col):
    if chart_type == "Bar":
        if pd.api.types.is_numeric_dtype(df[y_col]):
            plot_df = df.groupby(x_col, dropna=False)[y_col].mean().reset_index()
        else:
            plot_df = df[x_col].value_counts().reset_index()
            plot_df.columns = [x_col, "count"]
            y_col = "count"
        return px.bar(plot_df, x=x_col, y=y_col, title=f"Average {y_col} by {x_col}")

    if chart_type == "Line":
        if not pd.api.types.is_numeric_dtype(df[y_col]):
            raise ValueError("Line charts require a numerical Y-axis.")
        return px.line(df, x=x_col, y=y_col, title=f"{y_col} over {x_col}")

    if chart_type == "Pie":
        if not pd.api.types.is_numeric_dtype(df[y_col]):
            raise ValueError("Pie charts require a numerical value column.")
        values = df.groupby(x_col, dropna=False)[y_col].sum().reset_index()
        return px.pie(values, names=x_col, values=y_col, title=f"{y_col} by {x_col}")

    if chart_type == "Histogram":
        return px.histogram(df, x=x_col, nbins=30, title=f"Distribution of {x_col}")

    if chart_type == "Box Plot":
        if pd.api.types.is_numeric_dtype(df[y_col]):
            if pd.api.types.is_numeric_dtype(df[x_col]):
                return px.box(df, y=y_col, title=f"Distribution of {y_col}")
            return px.box(df, x=x_col, y=y_col, title=f"{y_col} by {x_col}")
        if pd.api.types.is_numeric_dtype(df[x_col]):
            return px.box(df, y=x_col, title=f"Distribution of {x_col}")
        raise ValueError("Box plots need at least one numerical column.")

    if chart_type == "Scatter":
        if not (pd.api.types.is_numeric_dtype(df[x_col]) and pd.api.types.is_numeric_dtype(df[y_col])):
            raise ValueError("Scatter plots require two numerical variables.")
        # Avoid Plotly's statsmodels-backed OLS trendline so the lightweight
        # DataNova build does not need the blocked compiled scientific stack.
        clean = df[[x_col, y_col]].apply(pd.to_numeric, errors="coerce").dropna()
        fig = px.scatter(clean, x=x_col, y=y_col, title=f"{y_col} vs {x_col}")
        if len(clean) >= 2 and clean[x_col].nunique() > 1:
            slope, intercept = __import__("numpy").polyfit(clean[x_col], clean[y_col], 1)
            xs = __import__("numpy").linspace(clean[x_col].min(), clean[x_col].max(), 80)
            ys = slope * xs + intercept
            fig.add_scatter(x=xs, y=ys, mode="lines", name="Linear trend")
        return fig

    if chart_type == "Area":
        if not pd.api.types.is_numeric_dtype(df[y_col]):
            raise ValueError("Area charts require a numerical Y-axis.")
        return px.area(df, x=x_col, y=y_col, title=f"{y_col} over {x_col}")

    if chart_type == "Heatmap":
        numeric = df.select_dtypes("number")
        if numeric.shape[1] < 2:
            raise ValueError("Heatmap requires at least two numerical columns.")
        return px.imshow(numeric.corr(), text_auto=".2f", title="Correlation Heatmap")

    raise ValueError("Unsupported chart type.")
