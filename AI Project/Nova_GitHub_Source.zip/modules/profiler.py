import pandas as pd

def _looks_like_date(series):
    if pd.api.types.is_datetime64_any_dtype(series): return True
    if not (pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series)): return False
    sample=series.dropna().astype(str).head(100)
    if sample.empty: return False
    parsed=pd.to_datetime(sample,errors='coerce')
    return parsed.notna().mean()>=0.8

def profile_dataset(df):
    numeric=[]; categorical=[]; dates=[]; text=[]
    for col in df.columns:
        s=df[col]
        if _looks_like_date(s): dates.append(col)
        elif pd.api.types.is_numeric_dtype(s): numeric.append(col)
        elif pd.api.types.is_object_dtype(s) or pd.api.types.is_string_dtype(s):
            nunique=s.nunique(dropna=True)
            if nunique<=max(25,int(len(df)*0.05)): categorical.append(col)
            else: text.append(col)
        else: categorical.append(col)
    types={**{c:'Numerical' for c in numeric},**{c:'Categorical' for c in categorical},**{c:'Date / Time' for c in dates},**{c:'Text' for c in text}}
    return {'numeric_columns':numeric,'categorical_columns':categorical,'date_columns':dates,'text_columns':text,'types':types}

def dataset_health(df):
    return {'missing_cells':int(df.isna().sum().sum()),'missing_columns':int((df.isna().sum()>0).sum()),'duplicate_rows':int(df.duplicated().sum()),'memory_mb':float(df.memory_usage(deep=True).sum()/(1024**2))}
