import numpy as np
import pandas as pd

def expected_value_analysis(decision_names,probabilities,payoff_rows):
    probs=np.array(probabilities,dtype=float)
    if not np.isclose(probs.sum(),1.0): probs=probs/probs.sum()
    rows=[]
    for name,payoffs in zip(decision_names,payoff_rows):
        p=np.array(payoffs,dtype=float)
        if len(p)!=len(probs): raise ValueError('Every decision must have the same number of scenario payoffs as probabilities.')
        rows.append({'Decision':name,'Expected Value':float(np.dot(probs,p))})
    return pd.DataFrame(rows)
