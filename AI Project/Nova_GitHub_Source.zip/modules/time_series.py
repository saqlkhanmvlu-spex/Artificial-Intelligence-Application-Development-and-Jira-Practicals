import pandas as pd
import numpy as np
import plotly.graph_objects as go


def time_series_analysis(df, date_col, value_col):
    data = df[[date_col, value_col]].copy()
    data[date_col] = pd.to_datetime(data[date_col], errors="coerce")
    data[value_col] = pd.to_numeric(data[value_col], errors="coerce")
    data = data.dropna().sort_values(date_col)
    if data.empty:
        raise ValueError("No valid date/numeric rows were found.")
    data = data.groupby(date_col, as_index=False)[value_col].mean()
    data["moving_average"] = data[value_col].rolling(7, min_periods=1).mean()
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=data[date_col], y=data[value_col], mode="lines+markers", name=value_col))
    fig.add_trace(go.Scatter(x=data[date_col], y=data["moving_average"], mode="lines", name="7-period moving average"))
    fig.update_layout(title=f"Time Series: {value_col}", xaxis_title=date_col, yaxis_title=value_col)
    return {"data": data, "figure": fig}


def forecast_series(data, horizon=7):
    date_col = data.columns[0]
    value_col = data.columns[1]

    work = data[[date_col, value_col]].copy()
    work[date_col] = pd.to_datetime(work[date_col], errors="coerce")
    work[value_col] = pd.to_numeric(work[value_col], errors="coerce")
    work = work.dropna().sort_values(date_col)

    dates = work[date_col]
    y = work[value_col].to_numpy(dtype=float)

    # Never throw a traceback for a small dataset. Use a sensible
    # fallback so the user still gets a visible forecast.
    if len(y) == 0:
        future = pd.date_range(pd.Timestamp.today().normalize(), periods=horizon, freq="D")
        forecast = np.zeros(horizon, dtype=float)
        model_name = "No historical values — zero baseline"
    elif len(y) == 1:
        future = pd.date_range(dates.iloc[-1] + pd.Timedelta(days=1), periods=horizon, freq="D")
        forecast = np.repeat(y[-1], horizon)
        model_name = "Single-point baseline"
    else:
        # Two or more observations: fit a simple linear trend.
        x = np.arange(len(y), dtype=float)
        slope, intercept = np.polyfit(x, y, 1)
        future_x = np.arange(len(y), len(y) + horizon, dtype=float)
        forecast = intercept + slope * future_x

        # Keep short histories stable by blending the trend with the recent mean.
        recent = y[-min(7, len(y)):].mean()
        blend = 0.55 if len(y) < 7 else 0.30
        forecast = (1 - blend) * forecast + blend * recent
        model_name = "Linear trend + recent-mean smoothing"

        # Infer the next date spacing only when pandas has enough dates.
        freq = None
        if len(dates) >= 3:
            try:
                freq = pd.infer_freq(dates)
            except (TypeError, ValueError):
                freq = None

        if freq:
            future = pd.date_range(dates.iloc[-1], periods=horizon + 1, freq=freq)[1:]
        else:
            diffs = dates.diff().dropna()
            step = diffs.median() if not diffs.empty else pd.Timedelta(days=1)
            if step <= pd.Timedelta(0):
                step = pd.Timedelta(days=1)
            future = pd.DatetimeIndex(
                [dates.iloc[-1] + step * (i + 1) for i in range(horizon)]
            )

    if len(y) <= 1 and len(y) > 0:
        step = pd.Timedelta(days=1)
        future = pd.DatetimeIndex(
            [dates.iloc[-1] + step * (i + 1) for i in range(horizon)]
        )

    fig = go.Figure()
    if len(y) > 0:
        fig.add_trace(
            go.Scatter(
                x=dates,
                y=y,
                mode="lines+markers",
                name="Historical",
            )
        )
    fig.add_trace(
        go.Scatter(
            x=future,
            y=forecast,
            mode="lines+markers",
            name="Forecast",
        )
    )
    fig.update_layout(
        title="Forecast",
        xaxis_title="Date",
        yaxis_title=value_col,
        margin=dict(l=20, r=20, t=55, b=20),
    )

    return {
        "figure": fig,
        "model": model_name,
        "forecast": pd.DataFrame({"Date": future, "Forecast": forecast}),
    }
