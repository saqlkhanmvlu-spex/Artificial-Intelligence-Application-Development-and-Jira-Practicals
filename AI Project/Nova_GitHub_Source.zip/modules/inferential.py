import math
import numpy as np
import pandas as pd


def _z_critical(level):
    # Common normal critical values. Used instead of SciPy so DataNova
    # can run in environments that block compiled scientific extensions.
    return {0.90: 1.644854, 0.95: 1.959964, 0.99: 2.575829}.get(round(level, 2), 1.959964)


def _normal_two_sided_p(z):
    return math.erfc(abs(float(z)) / math.sqrt(2.0))


def confidence_interval(series, level=0.95):
    x = pd.to_numeric(series, errors="coerce").dropna().to_numpy(dtype=float)
    if len(x) < 2:
        raise ValueError("At least two observations are required.")
    mean = float(x.mean())
    se = float(x.std(ddof=1) / math.sqrt(len(x)))
    z = _z_critical(level)
    margin = z * se
    return {
        "mean": mean,
        "lower": mean - margin,
        "upper": mean + margin,
        "n": int(len(x)),
        "method": "Normal approximation",
    }


def bootstrap_confidence_interval(series, level=0.95, iterations=1000):
    x = pd.to_numeric(series, errors="coerce").dropna().to_numpy(dtype=float)
    if len(x) < 5:
        raise ValueError("At least five observations are recommended for bootstrap analysis.")
    rng = np.random.default_rng(42)
    samples = rng.choice(x, size=(iterations, len(x)), replace=True)
    means = samples.mean(axis=1)
    alpha = 1 - level
    lower, upper = np.quantile(means, [alpha / 2, 1 - alpha / 2])
    return {"lower": float(lower), "upper": float(upper), "mean": float(x.mean())}


def hypothesis_test(series, mu0):
    x = pd.to_numeric(series, errors="coerce").dropna().to_numpy(dtype=float)
    if len(x) < 2:
        raise ValueError("At least two observations are required.")
    se = x.std(ddof=1) / math.sqrt(len(x))
    if se == 0:
        z = 0.0 if x.mean() == mu0 else float("inf")
        p = 1.0 if x.mean() == mu0 else 0.0
    else:
        z = (x.mean() - mu0) / se
        p = _normal_two_sided_p(z)
    return {
        "test_statistic": float(z),
        "p_value_approx": float(p),
        "alpha": 0.05,
        "decision": "Reject H0" if p < 0.05 else "Fail to reject H0",
        "method": "One-sample normal approximation",
    }


def ab_test(a, b):
    a = pd.to_numeric(a, errors="coerce").dropna().to_numpy(dtype=float)
    b = pd.to_numeric(b, errors="coerce").dropna().to_numpy(dtype=float)
    if len(a) < 2 or len(b) < 2:
        raise ValueError("Both groups need at least two observations.")
    mean_diff = float(a.mean() - b.mean())
    se = math.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
    z = mean_diff / se if se else 0.0
    p = _normal_two_sided_p(z)
    return {
        "group_A_mean": float(a.mean()),
        "group_B_mean": float(b.mean()),
        "test_statistic": float(z),
        "p_value_approx": float(p),
        "decision_at_5pct": "Significant difference" if p < 0.05 else "No statistically significant difference",
        "method": "Two-sample normal approximation",
    }


def anova_test(df, group_col, value_col):
    clean = df[[group_col, value_col]].copy()
    clean[value_col] = pd.to_numeric(clean[value_col], errors="coerce")
    clean = clean.dropna()
    grouped = [g[value_col].to_numpy(dtype=float) for _, g in clean.groupby(group_col)]
    if len(grouped) < 2:
        raise ValueError("ANOVA needs at least two groups.")
    all_values = np.concatenate(grouped)
    grand_mean = all_values.mean()
    k = len(grouped)
    n = len(all_values)
    ss_between = sum(len(g) * (g.mean() - grand_mean) ** 2 for g in grouped)
    ss_within = sum(((g - g.mean()) ** 2).sum() for g in grouped)
    df_between = k - 1
    df_within = n - k
    ms_between = ss_between / df_between if df_between else 0
    ms_within = ss_within / df_within if df_within else 0
    f_stat = ms_between / ms_within if ms_within else float("inf")

    # A conservative educational interpretation. Exact F-distribution p-values
    # are intentionally avoided so the project does not depend on SciPy.
    significant = f_stat > 3.0
    return {
        "groups": int(k),
        "F_statistic": float(f_stat),
        "p_value_note": "Exact F-distribution p-value not used in this lightweight build.",
        "decision_at_5pct": "Potential significant group difference" if significant else "No strong evidence of a group difference",
        "method": "One-way ANOVA F statistic",
    }
