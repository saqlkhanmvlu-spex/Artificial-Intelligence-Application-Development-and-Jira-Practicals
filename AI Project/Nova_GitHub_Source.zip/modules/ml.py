import math
import numpy as np
import pandas as pd
import plotly.express as px


def _encode_features(df, features):
    X = df[features].copy()
    out = pd.DataFrame(index=X.index)
    for col in features:
        s = X[col]
        if pd.api.types.is_numeric_dtype(s):
            vals = pd.to_numeric(s, errors="coerce")
            vals = vals.fillna(vals.median() if vals.notna().any() else 0.0)
            out[col] = vals.astype(float)
        else:
            vals = s.astype(str).replace("nan", "Missing")
            codes, _ = pd.factorize(vals)
            out[col] = codes.astype(float)
    return out


def _split_data(X, y, test_size=0.25, seed=42):
    rng = np.random.default_rng(seed)
    indices = np.arange(len(X))
    rng.shuffle(indices)
    cut = max(1, int(len(X) * (1 - test_size)))
    train_idx, test_idx = indices[:cut], indices[cut:]
    if len(test_idx) == 0:
        test_idx = train_idx[-1:]
        train_idx = train_idx[:-1]
    return X.iloc[train_idx], X.iloc[test_idx], y.iloc[train_idx], y.iloc[test_idx]


def _gini(y):
    if len(y) == 0:
        return 0.0
    _, counts = np.unique(y, return_counts=True)
    p = counts / len(y)
    return float(1 - np.sum(p ** 2))


def _best_split(X, y):
    best = None
    base = _gini(y)
    for col in X.columns:
        values = X[col].to_numpy(dtype=float)
        unique = np.unique(values)
        if len(unique) < 2:
            continue
        thresholds = unique if len(unique) <= 15 else np.quantile(unique, np.linspace(0.1, 0.9, 9))
        for threshold in thresholds:
            left = values <= threshold
            right = ~left
            if left.sum() == 0 or right.sum() == 0:
                continue
            score = (left.sum() * _gini(y[left]) + right.sum() * _gini(y[right])) / len(y)
            gain = base - score
            if best is None or gain > best[0]:
                best = (gain, col, float(threshold))
    return best


class _Node:
    def __init__(self, prediction, feature=None, threshold=None, left=None, right=None):
        self.prediction = prediction
        self.feature = feature
        self.threshold = threshold
        self.left = left
        self.right = right


def _build_tree(X, y, depth=0, max_depth=4, min_samples=4):
    values, counts = np.unique(y, return_counts=True)
    prediction = values[np.argmax(counts)]
    node = _Node(prediction)
    if depth >= max_depth or len(y) < min_samples or len(values) == 1:
        return node
    split = _best_split(X, y)
    if not split or split[0] <= 1e-9:
        return node
    _, feature, threshold = split
    mask = X[feature].to_numpy(dtype=float) <= threshold
    node.feature, node.threshold = feature, threshold
    node.left = _build_tree(X.loc[mask], y.loc[mask], depth + 1, max_depth, min_samples)
    node.right = _build_tree(X.loc[~mask], y.loc[~mask], depth + 1, max_depth, min_samples)
    return node


def _predict_one(node, row):
    while node.left is not None and node.right is not None:
        node = node.left if float(row[node.feature]) <= node.threshold else node.right
    return node.prediction


def _classification_report(y_true, y_pred):
    labels = sorted(set(y_true.astype(str)) | set(y_pred.astype(str)))
    rows = []
    for label in labels:
        yt = y_true.astype(str) == label
        yp = y_pred.astype(str) == label
        tp = int(np.sum(yt & yp))
        fp = int(np.sum(~yt & yp))
        fn = int(np.sum(yt & ~yp))
        support = int(np.sum(yt))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        rows.append({"label": label, "precision": precision, "recall": recall, "f1-score": f1, "support": support})
    return pd.DataFrame(rows)


def _classification(df, features, target, depth):
    if not features:
        raise ValueError("Select at least one feature.")
    data = df[list(dict.fromkeys(features + [target]))].dropna(subset=[target]).copy()
    if data[target].nunique() < 2:
        raise ValueError("Target must contain at least two classes.")
    if data[target].nunique() > max(20, int(len(data) * 0.5)):
        raise ValueError("The selected target has too many unique values for a basic classification demo.")

    X_all = _encode_features(data, features)
    y_all = data[target].astype(str)
    Xtr, Xte, ytr, yte = _split_data(X_all, y_all)
    root = _build_tree(Xtr.reset_index(drop=True), ytr.reset_index(drop=True), max_depth=depth)
    pred = np.array([_predict_one(root, row) for _, row in Xte.reset_index(drop=True).iterrows()], dtype=str)
    y_true = yte.reset_index(drop=True).to_numpy(dtype=str)
    accuracy = float(np.mean(pred == y_true))
    report = _classification_report(y_true, pred)
    return {
        "accuracy": accuracy,
        "report": report,
        "explanation": f"A lightweight Decision Tree classifier (max depth {depth}) was implemented directly in Python/NumPy, avoiding external compiled ML extensions.",
    }


def classification_model(df, features, target):
    return _classification(df, features, target, 5)


def decision_tree_model(df, features, target):
    return _classification(df, features, target, 4)


def regression_model(df, x_col, y_col):
    features = x_col if isinstance(x_col, list) else [x_col]
    data = df[list(dict.fromkeys(features + [y_col]))].copy()
    for col in features + [y_col]:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data = data.dropna()
    if not features:
        raise ValueError("Select at least one predictor.")
    if len(data) < 4:
        raise ValueError("At least four usable rows are required for regression.")

    X = data[features].to_numpy(dtype=float)
    y = data[y_col].to_numpy(dtype=float)
    X_design = np.column_stack([np.ones(len(X)), X])
    coef, *_ = np.linalg.lstsq(X_design, y, rcond=None)
    pred_all = X_design @ coef

    rng = np.random.default_rng(42)
    idx = np.arange(len(X))
    rng.shuffle(idx)
    cut = max(2, int(len(X) * 0.75))
    test = idx[cut:]
    if len(test) < 1:
        test = idx[-1:]
    y_test = y[test]
    pred = pred_all[test]
    ss_res = float(np.sum((y_test - pred) ** 2))
    ss_tot = float(np.sum((y_test - y_test.mean()) ** 2))
    r2 = 1 - ss_res / ss_tot if ss_tot else 0.0
    rmse = math.sqrt(float(np.mean((y_test - pred) ** 2)))

    if len(features) == 1:
        order = np.argsort(X[test, 0])
        fig = px.scatter(
            x=X[test, 0], y=y_test,
            labels={"x": features[0], "y": y_col},
            title=f"Regression: {y_col} vs {features[0]}",
        )
        fig.add_scatter(x=X[test, 0][order], y=pred[order], mode="lines", name="Predicted")
    else:
        fig = px.scatter(x=y_test, y=pred, labels={"x": "Actual", "y": "Predicted"}, title="Regression: Actual vs Predicted")

    return {
        "summary": {
            "R2": float(r2),
            "RMSE": float(rmse),
            "coefficients": coef[1:].tolist(),
            "intercept": float(coef[0]),
        },
        "figure": fig,
    }
