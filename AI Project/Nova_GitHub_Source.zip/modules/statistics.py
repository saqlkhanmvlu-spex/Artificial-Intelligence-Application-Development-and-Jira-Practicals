import math
import pandas as pd


def descriptive_statistics(series):
    s = pd.to_numeric(series, errors="coerce").dropna().astype(float)
    if s.empty:
        raise ValueError("No numeric values are available.")

    mode_values = s.mode()
    mode_text = ", ".join(str(x) for x in mode_values.head(5).tolist())
    q1, q2, q3 = s.quantile([0.25, 0.5, 0.75])

    # Moment-based skewness without SciPy.
    if len(s) > 2 and s.std(ddof=1) != 0:
        mean = s.mean()
        m2 = ((s - mean) ** 2).mean()
        m3 = ((s - mean) ** 3).mean()
        skew = m3 / (m2 ** 1.5) if m2 else 0.0
        n = len(s)
        skew = math.sqrt(n * (n - 1)) / (n - 2) * skew
    else:
        skew = 0.0

    return pd.DataFrame(
        {
            "Metric": [
                "Count", "Mean", "Median", "Mode", "Variance",
                "Standard Deviation", "Minimum", "Q1", "Q2 / Median",
                "Q3", "Maximum", "Range", "Skewness"
            ],
            "Value": [
                len(s), s.mean(), s.median(), mode_text, s.var(), s.std(),
                s.min(), q1, q2, q3, s.max(), s.max() - s.min(), skew
            ],
        }
    )
