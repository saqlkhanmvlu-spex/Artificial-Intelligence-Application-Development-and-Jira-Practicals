import math
import numpy as np
import pandas as pd
import plotly.express as px


def dice_simulation(rolls, target):
    values = np.random.default_rng(42).integers(1, 7, rolls)
    counts = pd.Series(values).value_counts().sort_index()
    counts = counts.reindex(range(1, 7), fill_value=0)
    return {"counts": counts, "estimated": float((values == target).mean())}


def binomial_simulation(n, p, simulations):
    samples = np.random.default_rng(42).binomial(n, p, simulations)
    counts = np.bincount(samples, minlength=n + 1)
    return {
        "distribution": pd.DataFrame({"successes": np.arange(n + 1), "frequency": counts}).set_index("successes"),
        "expected": n * p,
    }


def distribution_simulation(name, samples):
    rng = np.random.default_rng(42)
    if name == "Normal":
        data = rng.normal(0, 1, samples)
        x = np.linspace(-4, 4, 400)
        y = np.exp(-0.5 * x ** 2) / math.sqrt(2 * math.pi)
    elif name == "Uniform":
        data = rng.uniform(-2, 2, samples)
        x = np.linspace(-2, 2, 400)
        y = np.where((x >= -2) & (x <= 2), 0.25, 0)
    else:
        data = rng.exponential(1, samples)
        x = np.linspace(0, 7, 400)
        y = np.exp(-x)
    fig = px.histogram(data, nbins=35, histnorm="probability density", title=f"{name} Distribution Simulation")
    fig.add_scatter(x=x, y=y, mode="lines", name="Theoretical density")
    return fig
