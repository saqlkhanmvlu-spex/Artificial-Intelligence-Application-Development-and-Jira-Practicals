import io
import pandas as pd

def load_uploaded_file(uploaded_file):
    name=uploaded_file.name.lower(); data=uploaded_file.getvalue()
    if name.endswith('.csv'):
        for encoding in ['utf-8','utf-8-sig','latin1']:
            try: return pd.read_csv(io.BytesIO(data),encoding=encoding)
            except UnicodeDecodeError: continue
        raise ValueError('Unable to decode the CSV file.')
    if name.endswith(('.xlsx','.xls')): return pd.read_excel(io.BytesIO(data))
    raise ValueError('Unsupported file type. Use CSV or Excel.')
