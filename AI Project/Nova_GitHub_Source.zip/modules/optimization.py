import numpy as np
import plotly.express as px


def inventory_simulation(starting_inventory, average_demand, days):
    demand = np.maximum(
        0,
        np.random.default_rng(42).normal(average_demand, max(1, average_demand * 0.25), days),
    ).round().astype(int)
    inventory = []
    current = int(starting_inventory)
    stockouts = 0
    for d in demand:
        current -= int(d)
        if current < 0:
            stockouts += 1
            current = 0
        inventory.append(current)
    fig = px.line(
        x=np.arange(1, days + 1),
        y=inventory,
        labels={"x": "Day", "y": "Ending Inventory"},
        title="Inventory Simulation",
    )
    return {
        "figure": fig,
        "summary": {
            "starting_inventory": int(starting_inventory),
            "average_demand": float(np.mean(demand)),
            "ending_inventory": int(inventory[-1]),
            "stockout_days": int(stockouts),
        },
    }


def linear_programming_demo():
    # Maximize 40x + 30y subject to 2x + y <= 40 and x + 2y <= 40.
    # Solve the small two-variable teaching example analytically.
    candidates = [(0.0, 0.0), (20.0, 0.0), (0.0, 20.0), (40 / 3, 40 / 3)]
    best = max(candidates, key=lambda xy: 40 * xy[0] + 30 * xy[1])
    x, y = best
    objective = 40 * x + 30 * y
    return {
        "objective_max": float(objective),
        "product_A_units": float(x),
        "product_B_units": float(y),
        "status": "Solved using a two-variable corner-point method",
    }
