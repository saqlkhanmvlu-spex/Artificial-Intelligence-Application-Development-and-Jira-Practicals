from collections import deque
import heapq

def _graph(): return {'A':{'B':1,'C':4},'B':{'A':1,'D':2,'E':5},'C':{'A':4,'F':3},'D':{'B':2,'G':1},'E':{'B':5,'G':2},'F':{'C':3,'G':2},'G':{'D':1,'E':2,'F':2}}

def _bfs(g,s,t):
    q=deque([(s,[s])]); seen={s}; vis=[]
    while q:
        n,p=q.popleft(); vis.append(n)
        if n==t:return vis,p
        for v in g[n]:
            if v not in seen: seen.add(v); q.append((v,p+[v]))
    return vis,[]

def _dfs(g,s,t):
    stack=[(s,[s])]; seen=set(); vis=[]
    while stack:
        n,p=stack.pop()
        if n in seen: continue
        seen.add(n); vis.append(n)
        if n==t:return vis,p
        for v in reversed(list(g[n])):
            if v not in seen: stack.append((v,p+[v]))
    return vis,[]

def _astar(g,s,t):
    h={'A':3,'B':2,'C':3,'D':1,'E':2,'F':1,'G':0}; heap=[(h[s],0,s,[s])]; best={s:0}; vis=[]
    while heap:
        _,cost,n,p=heapq.heappop(heap)
        if cost!=best.get(n): continue
        vis.append(n)
        if n==t:return vis,p
        for v,w in g[n].items():
            nc=cost+w
            if nc<best.get(v,float('inf')): best[v]=nc; heapq.heappush(heap,(nc+h[v],nc,v,p+[v]))
    return vis,[]

def search_demo(algorithm):
    g=_graph(); fn={'BFS':_bfs,'DFS':_dfs,'A*':_astar}[algorithm]; vis,path=fn(g,'A','G'); return {'visited':vis,'path':path}

def agent_demo(grid_size):
    x=y=0; gx=gy=grid_size-1; blocked={(1,2),(2,2),(3,1)} if grid_size>=4 else set(); steps=[]
    for step in range(grid_size*grid_size):
        steps.append({'Step':step+1,'Position':f'({x},{y})','Action':'Observe'})
        if (x,y)==(gx,gy): steps[-1]['Action']='Goal reached'; break
        candidates=[]
        if x<gx:candidates.append((x+1,y,'Move Right'))
        if y<gy:candidates.append((x,y+1,'Move Down'))
        if y>0:candidates.append((x,y-1,'Move Up'))
        if x>0:candidates.append((x-1,y,'Move Left'))
        candidates.sort(key=lambda p:abs(gx-p[0])+abs(gy-p[1])); moved=False
        for nx,ny,action in candidates:
            if (nx,ny) not in blocked: x,y=nx,ny; steps[-1]['Action']=action; moved=True; break
        if not moved: steps[-1]['Action']='No valid move'; break
    return steps
