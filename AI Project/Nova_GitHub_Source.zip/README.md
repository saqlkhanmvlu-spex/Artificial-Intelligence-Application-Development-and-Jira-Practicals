# Nova — Intelligent Data Analysis & Business Insight Platform

Nova is a Python + Streamlit academic analytics platform combining Artificial Intelligence and Applied Business Analytics in one dataset-first workflow.

## Workflow

UPLOAD → UNDERSTAND → RECOMMEND → ANALYSE → VISUALIZE → PREDICT → INTERPRET

## Features

- CSV / Excel upload
- Multiple datasets and comparison workspace
- Automatic dataset profiling and health checks
- Dataset-specific recommendations
- Descriptive statistics
- Interactive charts and correlation
- Regression
- Probability and distribution simulations
- Sampling and confidence intervals
- Hypothesis testing, A/B testing and ANOVA
- Time-series analysis and small-data-safe forecasting
- Expected-value decisions, inventory simulation and optimization demo
- AI intelligent-agent and BFS / DFS / A* demonstrations
- Classification and Decision Tree workflows
- AI ethics and safety
- Academic mapping for AI and Applied Business syllabus

## Run locally

```bash
python -m venv .venv

# Windows PowerShell
.venv\Scripts\activate

# macOS / Linux
source .venv/bin/activate

python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Then open `http://localhost:8501`.

## Project structure

```text
app.py
requirements.txt
modules/
  data_loader.py
  profiler.py
  recommendations.py
  statistics.py
  visualization.py
  probability.py
  inferential.py
  sampling.py
  regression/ML helpers
  search.py
  time_series.py
  optimization.py
  decision.py
data/sample_sales.csv
.streamlit/config.toml
```

## Deployment

This is a Streamlit/Python application. For Streamlit Community Cloud, upload these source files to a GitHub repository and select `app.py` as the main file.
